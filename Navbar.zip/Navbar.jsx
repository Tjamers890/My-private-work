import React from 'react'
import { useState } from 'react'
const Navbar = () => {
  const [navitems,setNavItems] = useState('bars')
  const [opacity,setOpacity] = useState('0')
  const [tops,setTop] = useState('-400px')
  const Menu = () =>{
    
    if (navitems=='bars') {
     setNavItems('close')
     setOpacity('100')
     setTop('80px')
    }
    else{
      setNavItems('bars')
      setOpacity('0')
      setTop('-400px')
    }
  }
  return (
    <div>
      <nav>
      <nav className='p-6 bg-white shadow md:flex  md:justify-between md:items-center '>
        <div className='flex justify-between items-center'>
          <span className='text-2xl font-medium  cursor-pointer'>Tailwind</span>
          <span className='text-3xl md:hidden' ><i className={`fa fa-${navitems}`} onClick={Menu}></i></span>
         
          </div>
          <ul className={`md:flex md:items-center z-[-1] md:z-auto md:static absolute bg-black md:bg-white text-white md:text-black w-[40%] h-full left-0 md:w-auto md:py-0 py-4 md:pl-0 pl-7 md:opacity-100 opacity-${opacity} top-[${tops}] transition-all ease-in duration-500 by-3`}>
            <li className='mx-4 my-6 md:my-0'>
              <a href="/" className='text-xl hover:text-cyan-500 duration-500'>Home</a>
            </li>
            <li className='mx-4 my-6 md:my-0'>
              <a href="/" className='text-xl hover:text-cyan-500 duration-500'>About</a>
            </li>
            <li className='mx-4 my-6 md:my-0'>
              <a href="/" className='text-xl hover:text-cyan-500 duration-500'>Contact</a>
            </li>
            <button className='bg-cyan-400 text-white font-[Poppins] duration-500 px-6 py-2 mx-4 hover:bg-cyan-500 rounded '>
              Get Started
            </button>
          </ul>
      </nav>
      </nav>
    </div>
  )
}

export default Navbar